using UnityEditor;
using UnityEngine;

namespace OmniCore.Editor
{
    public class OmniCoreSetupWindow : EditorWindow
    {
        private string _apiUrl = "https://omnicoreai.www-ahadprogamer.workers.dev";
        private string _apiKey = "omnicoreai_sfrgxer5gscr35fxsw";

        [MenuItem("Tools/OmniCore AI/Setup")]
        public static void ShowWindow()
        {
            OmniCoreSetupWindow win = GetWindow<OmniCoreSetupWindow>("OmniCore AI Setup");
            win.minSize = new Vector2(420, 280);
        }

        [MenuItem("Tools/OmniCore AI/Add to Scene")]
        public static void AddToScene()
        {
            OmniCoreAI existing = FindObjectOfType<OmniCoreAI>();
            if (existing != null)
            {
                Selection.activeGameObject = existing.gameObject;
                return;
            }

            GameObject go = new GameObject("OmniCoreAI");
            go.AddComponent<OmniCoreAI>();
            Selection.activeGameObject = go;
            Undo.RegisterCreatedObjectUndo(go, "Create OmniCoreAI");
        }

        private void OnGUI()
        {
            GUILayout.Space(10);
            GUILayout.Label("OmniCore AI — Unity Plugin", EditorStyles.boldLabel);
            GUILayout.Space(6);

            EditorGUILayout.HelpBox("Paste your API URL and key below, then click Apply. The values will be saved to the OmniCoreAI component in your scene.", MessageType.Info);

            GUILayout.Space(8);
            _apiUrl = EditorGUILayout.TextField("API URL", _apiUrl);
            _apiKey = EditorGUILayout.TextField("API Key", _apiKey);

            GUILayout.Space(12);

            if (GUILayout.Button("Apply to Scene Component", GUILayout.Height(32)))
            {
                OmniCoreAI ai = FindObjectOfType<OmniCoreAI>();
                if (ai == null)
                {
                    GameObject go = new GameObject("OmniCoreAI");
                    ai = go.AddComponent<OmniCoreAI>();
                    Undo.RegisterCreatedObjectUndo(go, "Create OmniCoreAI");
                }
                Undo.RecordObject(ai, "Apply OmniCore Settings");
                ai.apiUrl = _apiUrl;
                ai.apiKey = _apiKey;
                EditorUtility.SetDirty(ai);
            }

            GUILayout.Space(6);

            if (GUILayout.Button("Add OmniCoreAI to Scene", GUILayout.Height(28)))
                AddToScene();
        }
    }
}
