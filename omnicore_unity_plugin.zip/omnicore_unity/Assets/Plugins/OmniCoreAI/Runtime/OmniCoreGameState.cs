using System.Collections.Generic;
using UnityEngine;

namespace OmniCore
{
    public class OmniCoreGameState
    {
        private Dictionary<string, object> _state = new Dictionary<string, object>();
        private List<object> _entities = new List<object>();
        private List<object> _eventLabels = new List<object>();

        public OmniCoreGameState SetPlayerHealth(float value)
        {
            _state["player_health"] = (double)Mathf.Clamp01(value);
            return this;
        }

        public OmniCoreGameState SetPlayerStamina(float value)
        {
            _state["player_stamina"] = (double)Mathf.Clamp01(value);
            return this;
        }

        public OmniCoreGameState SetPlayerAmmo(float value)
        {
            _state["player_ammo"] = (double)Mathf.Clamp01(value);
            return this;
        }

        public OmniCoreGameState SetPlayerPosition(Vector3 pos, float scale = 100f)
        {
            _state["player_pos_x"] = (double)(pos.x / scale);
            _state["player_pos_y"] = (double)(pos.y / scale);
            _state["player_pos_z"] = (double)(pos.z / scale);
            return this;
        }

        public OmniCoreGameState SetPlayerVelocity(Vector3 vel, float scale = 10f)
        {
            _state["player_vel_x"] = (double)(vel.x / scale);
            _state["player_vel_y"] = (double)(vel.y / scale);
            _state["player_vel_z"] = (double)(vel.z / scale);
            return this;
        }

        public OmniCoreGameState SetPlayerWeapon(string weaponType)
        {
            _state["player_weapon"] = weaponType;
            return this;
        }

        public OmniCoreGameState SetZoneDanger(float value)
        {
            _state["zone_danger"] = (double)Mathf.Clamp01(value);
            return this;
        }

        public OmniCoreGameState SetTimeRemaining(float value)
        {
            _state["time_remaining"] = (double)Mathf.Clamp01(value);
            return this;
        }

        public OmniCoreGameState SetVisibilityRange(float value)
        {
            _state["visibility_range"] = (double)Mathf.Clamp01(value);
            return this;
        }

        public OmniCoreGameState SetScore(float value)
        {
            _state["score"] = (double)value;
            return this;
        }

        public OmniCoreGameState SetCollisionFlags(int flags)
        {
            _state["collision_flags"] = (long)flags;
            return this;
        }

        public OmniCoreGameState SetTick(int tick)
        {
            _state["tick"] = (long)tick;
            return this;
        }

        public OmniCoreGameState AddEntity(
            string type,
            Vector3 position,
            float health = 1f,
            string weapon = "none",
            bool visible = true,
            bool attacking = false,
            bool moving = false,
            bool dead = false,
            bool shielded = false,
            bool stunned = false,
            bool crouching = false,
            bool inCover = false,
            int teamId = 0,
            float dangerScore = 0f,
            string label = "",
            float posScale = 100f)
        {
            var entity = new Dictionary<string, object>
            {
                { "type",         type },
                { "pos_x",        (double)(position.x / posScale) },
                { "pos_y",        (double)(position.y / posScale) },
                { "pos_z",        (double)(position.z / posScale) },
                { "health",       (double)Mathf.Clamp01(health) },
                { "weapon",       weapon },
                { "visible",      visible },
                { "attacking",    attacking },
                { "moving",       moving },
                { "dead",         dead },
                { "shielded",     shielded },
                { "stunned",      stunned },
                { "crouching",    crouching },
                { "in_cover",     inCover },
                { "team_id",      (long)teamId },
                { "danger_score", (double)Mathf.Clamp01(dangerScore) },
                { "label",        label }
            };
            _entities.Add(entity);
            return this;
        }

        public OmniCoreGameState AddEvent(string eventLabel)
        {
            _eventLabels.Add(eventLabel);
            return this;
        }

        public Dictionary<string, object> Build()
        {
            _state["entities"]     = _entities;
            _state["event_labels"] = _eventLabels;
            return _state;
        }

        public static OmniCoreGameState Create()
        {
            return new OmniCoreGameState();
        }
    }
}
