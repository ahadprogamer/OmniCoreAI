using System;
using System.Collections;
using UnityEngine;

namespace OmniCore
{
    public class OmniCoreMic : MonoBehaviour
    {
        public int recordingFrequency = 16000;
        public int maxRecordingSeconds = 30;

        public event Action<string> OnRecordingFinished;
        public event Action OnRecordingStarted;

        private AudioClip _recordingClip;
        private bool _isRecording = false;
        private float _recordingStartTime;

        public bool IsRecording => _isRecording;

        public void StartRecording()
        {
            if (_isRecording)
                return;

            if (Microphone.devices.Length == 0)
                return;

            _recordingClip = Microphone.Start(null, false, maxRecordingSeconds, recordingFrequency);
            _isRecording = true;
            _recordingStartTime = Time.realtimeSinceStartup;
            OnRecordingStarted?.Invoke();
        }

        public void StopRecording()
        {
            if (!_isRecording)
                return;

            int position = Microphone.GetPosition(null);
            Microphone.End(null);
            _isRecording = false;

            if (_recordingClip == null || position <= 0)
            {
                OnRecordingFinished?.Invoke("");
                return;
            }

            float[] samples = new float[position * _recordingClip.channels];
            _recordingClip.GetData(samples, 0);

            AudioClip trimmed = AudioClip.Create("recording", position, _recordingClip.channels, recordingFrequency, false);
            trimmed.SetData(samples, 0);

            OmniCoreAI ai = OmniCoreAI.Instance;
            if (ai != null)
            {
                string b64 = ai.AudioClipToBase64(trimmed);
                OnRecordingFinished?.Invoke(b64);
            }
            else
            {
                OnRecordingFinished?.Invoke("");
            }
        }

        public void RecordForDuration(float seconds)
        {
            StartCoroutine(RecordDurationCoroutine(seconds));
        }

        private IEnumerator RecordDurationCoroutine(float seconds)
        {
            StartRecording();
            yield return new WaitForSecondsRealtime(seconds);
            StopRecording();
        }
    }
}
