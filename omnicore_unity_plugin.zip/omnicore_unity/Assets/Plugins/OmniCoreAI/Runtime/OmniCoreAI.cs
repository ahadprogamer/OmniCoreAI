using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace OmniCore
{
    public class OmniCoreAI : MonoBehaviour
    {
        public static OmniCoreAI Instance { get; private set; }

        [Header("Connection")]
        public string apiUrl = "https://omnicoreai.www-ahadprogamer.workers.dev";
        public string apiKey = "omnicoreai_2rfrh2id4bt58dn4nfuw";

        [Header("Settings")]
        public float requestTimeout = 120f;

        public event Action<string, Dictionary<string, object>> OnResponseReceived;
        public event Action<Dictionary<string, object>> OnActionReceived;
        public event Action<string, string> OnDialogueReceived;
        public event Action<string> OnTTSReceived;
        public event Action<string, string> OnError;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        private IEnumerator PostCommand(string cmdLabel, Dictionary<string, object> body)
        {
            string json = OmniCoreJSON.Serialize(body);
            byte[] bodyBytes = Encoding.UTF8.GetBytes(json);

            using UnityWebRequest req = new UnityWebRequest(apiUrl + "/command", "POST");
            req.uploadHandler = new UploadHandlerRaw(bodyBytes);
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");
            req.SetRequestHeader("X-API-Key", apiKey);
            req.timeout = (int)requestTimeout;

            yield return req.SendWebRequest();

            if (req.result != UnityWebRequest.Result.Success)
            {
                OnError?.Invoke(cmdLabel, string.Format("HTTP {0} result {1}", req.responseCode, req.result));
                yield break;
            }

            string rawBody = req.downloadHandler.text;
            Dictionary<string, object> data = OmniCoreJSON.Deserialize(rawBody);

            if (data == null)
            {
                OnError?.Invoke(cmdLabel, "JSON parse failed");
                yield break;
            }

            OnResponseReceived?.Invoke(cmdLabel, data);

            string responseText = "";
            if (data.ContainsKey("response"))
                responseText = data["response"]?.ToString() ?? "";
            else if (data.ContainsKey("text"))
                responseText = data["text"]?.ToString() ?? "";

            string sourceName = data.ContainsKey("source") ? data["source"]?.ToString() ?? "ai" : "ai";

            if (!string.IsNullOrEmpty(responseText))
                OnDialogueReceived?.Invoke(responseText, sourceName);

            if (data.ContainsKey("audio_b64"))
            {
                string audiob64 = data["audio_b64"]?.ToString() ?? "";
                if (!string.IsNullOrEmpty(audiob64))
                    OnTTSReceived?.Invoke(audiob64);
            }

            if (cmdLabel == "run_ai" || cmdLabel == "game_state_parse")
            {
                Dictionary<string, object> actions = null;
                if (data.ContainsKey("actions"))
                    actions = data["actions"] as Dictionary<string, object>;
                else if (data.ContainsKey("ai_output"))
                    actions = data["ai_output"] as Dictionary<string, object>;

                if (actions != null && actions.Count > 0)
                    OnActionReceived?.Invoke(actions);
            }
            else if (cmdLabel == "listen_ai")
            {
                string transcribed = data.ContainsKey("text") ? data["text"]?.ToString() ?? "" : "";
                if (!string.IsNullOrEmpty(transcribed))
                    OnDialogueReceived?.Invoke("[STT]: " + transcribed, "stt");
            }
        }

        private void Send(string cmdLabel, Dictionary<string, object> body)
        {
            StartCoroutine(PostCommand(cmdLabel, body));
        }

        public void RunAI(float[] inputVector)
        {
            List<object> vec = new List<object>();
            foreach (float v in inputVector)
                vec.Add(v);

            Send("run_ai", new Dictionary<string, object>
            {
                { "cmd", "run_ai" },
                { "input", vec }
            });
        }

        public void TalkAI(string text, string personality, string gameContext, string style = "dialogue", string instructions = "")
        {
            Send("talk_ai", new Dictionary<string, object>
            {
                { "cmd", "ai_dialog" },
                { "text", text },
                { "role", personality },
                { "game_context", gameContext },
                { "style", style },
                { "instructions", string.IsNullOrEmpty(instructions) ? "Respond as this character in 1-2 sentences." : instructions },
                { "want_audio", false }
            });
        }

        public void TalkAndSpeak(string text, string personality, string gameContext, string style = "dialogue")
        {
            Send("talk_and_speak", new Dictionary<string, object>
            {
                { "cmd", "ai_dialog" },
                { "text", text },
                { "role", personality },
                { "game_context", gameContext },
                { "style", style },
                { "instructions", "Respond as this character in 1-2 sentences." },
                { "want_audio", true }
            });
        }

        public void SpeakAI(string text, string voiceName = "")
        {
            var body = new Dictionary<string, object>
            {
                { "cmd", "speak_ai" },
                { "text", text }
            };
            if (!string.IsNullOrEmpty(voiceName))
                body["voice_name"] = voiceName;
            Send("speak_ai", body);
        }

        public void ListenAI(string audioB64)
        {
            Send("listen_ai", new Dictionary<string, object>
            {
                { "cmd", "listen_ai" },
                { "audio", audioB64 },
                { "format", "wav" }
            });
        }

        public void ListenAndTalk(string audioB64, string personality, string gameContext, string style = "dialogue", string instructions = "", bool wantsVoice = false, string voiceName = "")
        {
            var body = new Dictionary<string, object>
            {
                { "cmd", "ai_dialog" },
                { "audio", audioB64 },
                { "role", personality },
                { "game_context", gameContext },
                { "style", style },
                { "instructions", string.IsNullOrEmpty(instructions) ? "Respond as this character in 1-2 sentences." : instructions },
                { "want_audio", wantsVoice }
            };
            if (!string.IsNullOrEmpty(voiceName))
                body["voice_name"] = voiceName;
            Send("talk_and_speak", body);
        }

        public void GameStateParse(Dictionary<string, object> gameState, string[] outputLabels = null)
        {
            var body = new Dictionary<string, object>
            {
                { "cmd", "game_state_parse" },
                { "game_state", gameState }
            };
            if (outputLabels != null && outputLabels.Length > 0)
            {
                List<object> labels = new List<object>(outputLabels.Length);
                foreach (string l in outputLabels)
                    labels.Add(l);
                body["output_labels"] = labels;
            }
            Send("game_state_parse", body);
        }

        public void GameStateSummary(Dictionary<string, object> gameState)
        {
            Send("game_state_summary", new Dictionary<string, object>
            {
                { "cmd", "game_state_summary" },
                { "game_state", gameState }
            });
        }

        public void TrainAI(int steps = 10, bool useCritic = true, bool forceRefresh = false)
        {
            Send("train_ai", new Dictionary<string, object>
            {
                { "cmd", "train_ai" },
                { "steps", steps },
                { "use_critic", useCritic },
                { "force_refresh", forceRefresh }
            });
        }

        public void PlayAudioFromBase64(string audioB64, AudioSource audioSource)
        {
            if (string.IsNullOrEmpty(audioB64) || audioSource == null)
                return;
            StartCoroutine(PlayAudioCoroutine(audioB64, audioSource));
        }

        private IEnumerator PlayAudioCoroutine(string audioB64, AudioSource audioSource)
        {
            byte[] raw = Convert.FromBase64String(audioB64);

            if (raw.Length < 44)
                yield break;

            bool isWav = raw[0] == 'R' && raw[1] == 'I' && raw[2] == 'F' && raw[3] == 'F'
                      && raw[8] == 'W' && raw[9] == 'A' && raw[10] == 'V' && raw[11] == 'E';

            int sampleRate = 24000;
            int channels = 1;
            int dataOffset = 44;

            if (isWav)
            {
                channels   = raw[22] | (raw[23] << 8);
                sampleRate = raw[24] | (raw[25] << 8) | (raw[26] << 16) | (raw[27] << 24);

                int searchLimit = Math.Min(raw.Length - 8, 256);
                for (int i = 12; i < searchLimit; i++)
                {
                    if (raw[i] == 'd' && raw[i+1] == 'a' && raw[i+2] == 't' && raw[i+3] == 'a')
                    {
                        dataOffset = i + 8;
                        break;
                    }
                }
            }

            int pcmLength = raw.Length - dataOffset;
            if (pcmLength <= 0)
                yield break;

            int sampleCount = pcmLength / 2;
            float[] samples = new float[sampleCount];
            for (int i = 0; i < sampleCount; i++)
            {
                int byteIdx = dataOffset + i * 2;
                short s = (short)(raw[byteIdx] | (raw[byteIdx + 1] << 8));
                samples[i] = s / 32768f;
            }

            AudioClip clip = AudioClip.Create("omnicore_audio", sampleCount, channels, sampleRate, false);
            clip.SetData(samples, 0);
            audioSource.clip = clip;
            audioSource.Play();

            yield break;
        }

        public string GetBestAction(Dictionary<string, object> actions)
        {
            string bestAction = "";
            float bestValue = float.MinValue;

            foreach (KeyValuePair<string, object> pair in actions)
            {
                float val = 0f;
                if (pair.Value is float f)
                    val = f;
                else if (pair.Value is double d)
                    val = (float)d;
                else
                    float.TryParse(pair.Value?.ToString(), out val);

                if (val > bestValue)
                {
                    bestValue = val;
                    bestAction = pair.Key;
                }
            }
            return bestAction;
        }

        public string AudioClipToBase64(AudioClip clip)
        {
            if (clip == null)
                return "";

            float[] samples = new float[clip.samples * clip.channels];
            clip.GetData(samples, 0);

            int sampleRate = clip.frequency;
            int channelCount = clip.channels;
            int sampleCount = samples.Length;
            int pcmLength = sampleCount * 2;
            int dataSize = pcmLength;
            int fileSize = 44 + dataSize;

            byte[] wav = new byte[fileSize];

            wav[0] = (byte)'R'; wav[1] = (byte)'I'; wav[2] = (byte)'F'; wav[3] = (byte)'F';
            WriteInt32(wav, 4, fileSize - 8);
            wav[8] = (byte)'W'; wav[9] = (byte)'A'; wav[10] = (byte)'V'; wav[11] = (byte)'E';
            wav[12] = (byte)'f'; wav[13] = (byte)'m'; wav[14] = (byte)'t'; wav[15] = (byte)' ';
            WriteInt32(wav, 16, 16);
            WriteInt16(wav, 20, 1);
            WriteInt16(wav, 22, (short)channelCount);
            WriteInt32(wav, 24, sampleRate);
            WriteInt32(wav, 28, sampleRate * channelCount * 2);
            WriteInt16(wav, 32, (short)(channelCount * 2));
            WriteInt16(wav, 34, 16);
            wav[36] = (byte)'d'; wav[37] = (byte)'a'; wav[38] = (byte)'t'; wav[39] = (byte)'a';
            WriteInt32(wav, 40, dataSize);

            for (int i = 0; i < sampleCount; i++)
            {
                short s = (short)Mathf.Clamp(samples[i] * 32767f, -32768f, 32767f);
                wav[44 + i * 2]     = (byte)(s & 0xFF);
                wav[44 + i * 2 + 1] = (byte)((s >> 8) & 0xFF);
            }

            return Convert.ToBase64String(wav);
        }

        private static void WriteInt32(byte[] buf, int offset, int value)
        {
            buf[offset]     = (byte)(value & 0xFF);
            buf[offset + 1] = (byte)((value >> 8)  & 0xFF);
            buf[offset + 2] = (byte)((value >> 16) & 0xFF);
            buf[offset + 3] = (byte)((value >> 24) & 0xFF);
        }

        private static void WriteInt16(byte[] buf, int offset, short value)
        {
            buf[offset]     = (byte)(value & 0xFF);
            buf[offset + 1] = (byte)((value >> 8) & 0xFF);
        }
    }
}
