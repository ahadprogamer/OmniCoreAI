using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace OmniCore
{
    public static class OmniCoreJSON
    {
        public static string Serialize(object obj)
        {
            if (obj == null)
                return "null";

            if (obj is bool b)
                return b ? "true" : "false";

            if (obj is string s)
                return "\"" + EscapeString(s) + "\"";

            if (obj is int i)
                return i.ToString();

            if (obj is long l)
                return l.ToString();

            if (obj is float f)
                return f.ToString("G", System.Globalization.CultureInfo.InvariantCulture);

            if (obj is double d)
                return d.ToString("G", System.Globalization.CultureInfo.InvariantCulture);

            if (obj is Dictionary<string, object> dict)
            {
                StringBuilder sb = new StringBuilder("{");
                bool first = true;
                foreach (KeyValuePair<string, object> pair in dict)
                {
                    if (!first) sb.Append(',');
                    sb.Append("\"");
                    sb.Append(EscapeString(pair.Key));
                    sb.Append("\":");
                    sb.Append(Serialize(pair.Value));
                    first = false;
                }
                sb.Append('}');
                return sb.ToString();
            }

            if (obj is IList list)
            {
                StringBuilder sb = new StringBuilder("[");
                bool first = true;
                foreach (object item in list)
                {
                    if (!first) sb.Append(',');
                    sb.Append(Serialize(item));
                    first = false;
                }
                sb.Append(']');
                return sb.ToString();
            }

            return "\"" + EscapeString(obj.ToString()) + "\"";
        }

        private static string EscapeString(string s)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in s)
            {
                switch (c)
                {
                    case '"':  sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n");  break;
                    case '\r': sb.Append("\\r");  break;
                    case '\t': sb.Append("\\t");  break;
                    default:   sb.Append(c);      break;
                }
            }
            return sb.ToString();
        }

        public static Dictionary<string, object> Deserialize(string json)
        {
            if (string.IsNullOrEmpty(json))
                return null;
            try
            {
                int idx = 0;
                object result = ParseValue(json, ref idx);
                return result as Dictionary<string, object>;
            }
            catch
            {
                return null;
            }
        }

        private static object ParseValue(string json, ref int idx)
        {
            SkipWhitespace(json, ref idx);

            if (idx >= json.Length)
                return null;

            char c = json[idx];

            if (c == '"')
                return ParseString(json, ref idx);

            if (c == '{')
                return ParseObject(json, ref idx);

            if (c == '[')
                return ParseArray(json, ref idx);

            if (c == 't')
            {
                idx += 4;
                return true;
            }

            if (c == 'f')
            {
                idx += 5;
                return false;
            }

            if (c == 'n')
            {
                idx += 4;
                return null;
            }

            return ParseNumber(json, ref idx);
        }

        private static void SkipWhitespace(string json, ref int idx)
        {
            while (idx < json.Length && (json[idx] == ' ' || json[idx] == '\t' || json[idx] == '\n' || json[idx] == '\r'))
                idx++;
        }

        private static string ParseString(string json, ref int idx)
        {
            idx++;
            StringBuilder sb = new StringBuilder();
            while (idx < json.Length)
            {
                char c = json[idx];
                if (c == '"')
                {
                    idx++;
                    return sb.ToString();
                }
                if (c == '\\' && idx + 1 < json.Length)
                {
                    idx++;
                    char esc = json[idx];
                    switch (esc)
                    {
                        case '"':  sb.Append('"');  break;
                        case '\\': sb.Append('\\'); break;
                        case 'n':  sb.Append('\n'); break;
                        case 'r':  sb.Append('\r'); break;
                        case 't':  sb.Append('\t'); break;
                        case 'u':
                            if (idx + 4 < json.Length)
                            {
                                string hex = json.Substring(idx + 1, 4);
                                sb.Append((char)Convert.ToInt32(hex, 16));
                                idx += 4;
                            }
                            break;
                        default:   sb.Append(esc);  break;
                    }
                }
                else
                {
                    sb.Append(c);
                }
                idx++;
            }
            return sb.ToString();
        }

        private static Dictionary<string, object> ParseObject(string json, ref int idx)
        {
            idx++;
            var dict = new Dictionary<string, object>();
            SkipWhitespace(json, ref idx);
            if (idx < json.Length && json[idx] == '}')
            {
                idx++;
                return dict;
            }
            while (idx < json.Length)
            {
                SkipWhitespace(json, ref idx);
                string key = ParseString(json, ref idx);
                SkipWhitespace(json, ref idx);
                if (idx < json.Length && json[idx] == ':')
                    idx++;
                object val = ParseValue(json, ref idx);
                dict[key] = val;
                SkipWhitespace(json, ref idx);
                if (idx < json.Length && json[idx] == '}')
                {
                    idx++;
                    return dict;
                }
                if (idx < json.Length && json[idx] == ',')
                    idx++;
            }
            return dict;
        }

        private static List<object> ParseArray(string json, ref int idx)
        {
            idx++;
            var list = new List<object>();
            SkipWhitespace(json, ref idx);
            if (idx < json.Length && json[idx] == ']')
            {
                idx++;
                return list;
            }
            while (idx < json.Length)
            {
                object val = ParseValue(json, ref idx);
                list.Add(val);
                SkipWhitespace(json, ref idx);
                if (idx < json.Length && json[idx] == ']')
                {
                    idx++;
                    return list;
                }
                if (idx < json.Length && json[idx] == ',')
                    idx++;
            }
            return list;
        }

        private static object ParseNumber(string json, ref int idx)
        {
            int start = idx;
            while (idx < json.Length)
            {
                char c = json[idx];
                if (c == ',' || c == '}' || c == ']' || c == ' ' || c == '\n' || c == '\r' || c == '\t')
                    break;
                idx++;
            }
            string numStr = json.Substring(start, idx - start);
            if (numStr.Contains(".") || numStr.Contains("e") || numStr.Contains("E"))
            {
                if (double.TryParse(numStr, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double d))
                    return d;
            }
            else
            {
                if (long.TryParse(numStr, out long l))
                    return l;
            }
            return 0;
        }
    }
}
