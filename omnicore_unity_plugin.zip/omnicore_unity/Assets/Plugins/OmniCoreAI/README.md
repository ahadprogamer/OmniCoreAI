# OmniCore AI — Unity Plugin

Turn any NPC into an AI-driven character with voice, personality, and adaptive
combat decisions. One plugin handles dialogue, text-to-speech, speech-to-text,
voice-to-voice conversation, and game-state AI vision.

---

## Install

1. Copy the `Assets/Plugins/OmniCoreAI` folder into your Unity project.
2. Open the scene you want to use OmniCore in.
3. In the menu bar: **Tools → OmniCore AI → Add to Scene**
4. Select the `OmniCoreAI` GameObject that appears and set your API URL and key in the Inspector.

Or use the setup window: **Tools → OmniCore AI → Setup**

---

## Quick Start

```csharp
using OmniCore;
using UnityEngine;

public class NPC : MonoBehaviour
{
    private AudioSource _audio;

    void Start()
    {
        _audio = GetComponent<AudioSource>();
        OmniCoreAI.Instance.OnDialogueReceived += OnDialogue;
        OmniCoreAI.Instance.OnActionReceived   += OnAction;
        OmniCoreAI.Instance.OnTTSReceived      += OnTTS;
        OmniCoreAI.Instance.OnError            += OnError;
    }

    void OnDialogue(string text, string source)
    {
        Debug.Log("NPC says: " + text);
    }

    void OnAction(Dictionary<string, object> actions)
    {
        string best = OmniCoreAI.Instance.GetBestAction(actions);
        Debug.Log("AI chose: " + best);
    }

    void OnTTS(string audioB64)
    {
        OmniCoreAI.Instance.PlayAudioFromBase64(audioB64, _audio);
    }

    void OnError(string cmd, string error)
    {
        Debug.LogError("OmniCore error in " + cmd + ": " + error);
    }
}
```

Now call any function from anywhere:

```csharp
OmniCoreAI.Instance.TalkAI("The player just attacked me!", "loyal warrior", "dark fantasy RPG");

OmniCoreAI.Instance.ListenAndTalk(micAudioB64, "loyal warrior", "dark fantasy RPG", "dialogue", "", true, "Charon");

OmniCoreAI.Instance.GameStateParse(gameStateDict, new string[] { "attack", "defend", "retreat", "idle" });
```

---

## Components

### OmniCoreAI (MonoBehaviour)

Add one instance to your scene. It persists across scenes automatically.

| Property | Description |
|---|---|
| `apiUrl` | Your OmniCore backend URL |
| `apiKey` | Your API key |
| `requestTimeout` | Seconds before a request is abandoned (default 120) |

### OmniCoreMic (MonoBehaviour)

Optional helper for recording microphone audio.

```csharp
OmniCoreMic mic = GetComponent<OmniCoreMic>();
mic.OnRecordingFinished += (audioB64) => {
    OmniCoreAI.Instance.ListenAndTalk(audioB64, "guard", "medieval RPG", "dialogue", "", true, "Fenrir");
};
mic.RecordForDuration(3f);
```

### OmniCoreGameState (Builder)

Fluent builder for game state dictionaries.

```csharp
var state = OmniCoreGameState.Create()
    .SetPlayerHealth(health / maxHealth)
    .SetPlayerPosition(transform.position)
    .SetPlayerVelocity(rb.linearVelocity)
    .SetPlayerWeapon("rifle")
    .SetZoneDanger(enemyNearby ? 0.8f : 0.1f)
    .AddEntity("enemy", enemy.transform.position, enemy.health, "melee", true, enemy.isAttacking)
    .AddEvent("under_fire")
    .Build();

string[] labels = { "attack_light", "attack_heavy", "block", "dodge", "retreat", "take_cover", "idle", "wait" };
OmniCoreAI.Instance.GameStateParse(state, labels);
```

---

## Methods

### Dialogue & Voice

| Method | Description |
|---|---|
| `TalkAI(text, personality, gameContext, style, instructions)` | Text dialogue only |
| `TalkAndSpeak(text, personality, gameContext, style)` | Dialogue + spoken audio |
| `SpeakAI(text, voiceName)` | Text-to-speech only |
| `ListenAI(audioB64)` | Speech-to-text only |
| `ListenAndTalk(audioB64, personality, gameContext, style, instructions, wantsVoice, voiceName)` | Voice-to-voice |
| `PlayAudioFromBase64(audioB64, audioSource)` | Plays returned audio. Handles WAV header automatically |

### AI Vision & Decisions

| Method | Description |
|---|---|
| `RunAI(inputVector)` | Raw 64-float input vector → action dictionary |
| `GameStateParse(gameState, outputLabels)` | Full game state snapshot → action dictionary |
| `GameStateSummary(gameState)` | Full game state snapshot → text summary |

### Utilities

| Method | Description |
|---|---|
| `GetBestAction(actions)` | Returns the key with the highest float value from an action dictionary |
| `AudioClipToBase64(clip)` | Converts an AudioClip to WAV base64 string for sending to the API |

---

## Events

| Event | Signature | Fires when |
|---|---|---|
| `OnResponseReceived` | `(string cmd, Dictionary data)` | Any request finishes |
| `OnActionReceived` | `(Dictionary actions)` | `RunAI` / `GameStateParse` returns |
| `OnDialogueReceived` | `(string text, string source)` | Dialogue text comes back |
| `OnTTSReceived` | `(string audioB64)` | Audio comes back |
| `OnError` | `(string cmd, string error)` | A request fails |

---

## Voice Names

Pass any of these to methods that accept `voiceName`:

- **Charon**, **Fenrir**, **Orus**, **Algenib**, **Puck** — male / deep
- **Aoede**, **Kore**, **Leda**, **Freya** — female / light

---

## AI Vision — Full Example

```csharp
using OmniCore;
using UnityEngine;
using System.Collections.Generic;

public class EnemyAI : MonoBehaviour
{
    public float health = 1f;
    public bool isAttacking = false;
    private Rigidbody _rb;

    void Start()
    {
        _rb = GetComponent<Rigidbody>();
        OmniCoreAI.Instance.OnActionReceived += OnAction;
        InvokeRepeating(nameof(RequestDecision), 0f, 0.5f);
    }

    void RequestDecision()
    {
        GameObject player = GameObject.FindWithTag("Player");
        if (player == null) return;

        var state = OmniCoreGameState.Create()
            .SetPlayerHealth(health)
            .SetPlayerPosition(player.transform.position)
            .SetPlayerVelocity(_rb.linearVelocity)
            .SetPlayerWeapon("melee")
            .SetZoneDanger(0.7f)
            .AddEntity("enemy", transform.position, health, "melee", true, isAttacking)
            .Build();

        OmniCoreAI.Instance.GameStateParse(state, new string[]
        {
            "attack_light", "attack_heavy", "block", "dodge",
            "use_ability", "retreat", "take_cover", "idle",
            "use_item", "call_ally", "taunt", "observe",
            "flank", "rush", "counter", "wait"
        });
    }

    void OnAction(Dictionary<string, object> actions)
    {
        string top = OmniCoreAI.Instance.GetBestAction(actions);
        switch (top)
        {
            case "attack_light":
            case "attack_heavy":
            case "rush":
            case "flank":
                AttackPlayer();
                break;
            case "retreat":
            case "take_cover":
                Retreat();
                break;
            default:
                Idle();
                break;
        }
    }

    void AttackPlayer() { }
    void Retreat() { }
    void Idle() { }
}
```

---

## Voice-to-Voice Example

```csharp
using OmniCore;
using UnityEngine;

public class VoiceNPC : MonoBehaviour
{
    private AudioSource _audio;
    private OmniCoreMic _mic;

    void Start()
    {
        _audio = GetComponent<AudioSource>();
        _mic = gameObject.AddComponent<OmniCoreMic>();
        _mic.OnRecordingFinished += OnMicDone;

        OmniCoreAI.Instance.OnDialogueReceived += OnDialogue;
        OmniCoreAI.Instance.OnTTSReceived      += OnTTS;
    }

    public void PlayerStartedTalking()
    {
        _mic.StartRecording();
    }

    public void PlayerStoppedTalking()
    {
        _mic.StopRecording();
    }

    void OnMicDone(string audioB64)
    {
        if (string.IsNullOrEmpty(audioB64)) return;
        OmniCoreAI.Instance.ListenAndTalk(
            audioB64,
            "loyal warrior companion",
            "dark fantasy RPG",
            "dialogue",
            "Respond as this character in 1-2 sentences.",
            true,
            "Charon"
        );
    }

    void OnDialogue(string text, string source)
    {
        Debug.Log("NPC: " + text);
    }

    void OnTTS(string audioB64)
    {
        OmniCoreAI.Instance.PlayAudioFromBase64(audioB64, _audio);
    }
}
```

---

## Troubleshooting

**No audio plays back**
- Make sure `AudioSource` is attached to the same or a nearby GameObject
- `PlayAudioFromBase64` handles the WAV header automatically — pass the raw base64 string

**Mic returns empty audio**
- Check that your build target has microphone permissions enabled
- On Android: add `RECORD_AUDIO` to your AndroidManifest
- On iOS: add `NSMicrophoneUsageDescription` to your Info.plist
- On PC: check OS microphone privacy settings

**HTTP 401**
- API key is missing or wrong — check the `apiKey` field on your OmniCoreAI component

**HTTP 429**
- Rate limit hit — reduce how often you call the API or wait before retrying

**HTTP 500**
- Server error — check your backend logs

---

## Version

Plugin v4.0 — compatible with OmniCore Game AI server v4.0+
Requires Unity 2022.3 LTS or newer
