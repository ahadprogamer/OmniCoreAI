extends Node

@export var api_url: String = "https://omnicoreai.www-ahadprogamer.workers.dev"
@export var api_key: String = "omnicoreai_sfrgxer5gscr35fxsw"

signal ai_response_received(cmd: String, data: Dictionary)
signal ai_action_received(actions: Dictionary)
signal ai_dialogue_received(text: String, source: String)
signal ai_tts_received(audio_b64: String)
signal ai_error(cmd: String, error: String)

var _http_pool: Array[HTTPRequest] = []
var _pending: Dictionary = {}


func _ready() -> void:
	for i in 4:
		var h := HTTPRequest.new()
		h.timeout = 120.0
		add_child(h)
		h.request_completed.connect(_on_request_completed.bind(h))
		_http_pool.append(h)


func _get_free_http() -> HTTPRequest:
	for h in _http_pool:
		if not _pending.has(h):
			return h
	var h := HTTPRequest.new()
	h.timeout = 120.0
	add_child(h)
	h.request_completed.connect(_on_request_completed.bind(h))
	_http_pool.append(h)
	return h


func _headers() -> PackedStringArray:
	return PackedStringArray([
		"Content-Type: application/json",
		"X-API-Key: %s" % api_key,
	])


func _post(cmd: String, body: Dictionary) -> void:
	var h := _get_free_http()
	_pending[h] = cmd
	h.request(api_url + "/command", _headers(), HTTPClient.METHOD_POST, JSON.stringify(body))


func _on_request_completed(result: int, code: int, headers: PackedStringArray, body: PackedByteArray, h: HTTPRequest) -> void:
	var cmd: String = _pending.get(h, "unknown")
	_pending.erase(h)

	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		ai_error.emit(cmd, "HTTP %d result %d" % [code, result])
		return

	var text_body := body.get_string_from_utf8()
	var parsed: Variant = JSON.parse_string(text_body)
	if parsed == null:
		ai_error.emit(cmd, "JSON parse failed.")
		return

	var data: Dictionary = parsed
	ai_response_received.emit(cmd, data)

	var response_text: String = ""
	if data.has("response"):
		response_text = str(data.get("response", ""))
	elif data.has("text"):
		response_text = str(data.get("text", ""))

	var source_name: String = str(data.get("source", "ai"))

	if response_text != "":
		ai_dialogue_received.emit(response_text, source_name)

	if data.has("audio_b64") and str(data.get("audio_b64", "")) != "":
		ai_tts_received.emit(str(data.get("audio_b64", "")))

	if cmd == "run_ai" or cmd == "game_state_parse":
		var actions: Dictionary = data.get("actions", data.get("ai_output", {}))
		if actions.size() > 0:
			ai_action_received.emit(actions)
	elif cmd == "listen_ai":
		var transcribed: String = str(data.get("text", ""))
		ai_dialogue_received.emit("[STT]: %s" % transcribed, "stt")


func run_ai(input_vector: Array) -> void:
	_post("run_ai", {"cmd": "run_ai", "input": input_vector})


func talk_ai(text: String, personality: String, game_context: String, style: String = "dialogue", instructions: String = "") -> void:
	var body: Dictionary = {
		"cmd": "ai_dialog",
		"text": text,
		"role": personality,
		"game_context": game_context,
		"style": style,
		"instructions": instructions if instructions != "" else "Respond as this character in 1-2 sentences.",
		"want_audio": false
	}
	_post("talk_ai", body)


func talk_and_speak(text: String, personality: String, game_context: String, style: String = "dialogue") -> void:
	var body: Dictionary = {
		"cmd": "ai_dialog",
		"text": text,
		"role": personality,
		"game_context": game_context,
		"style": style,
		"instructions": "Respond as this character in 1-2 sentences.",
		"want_audio": true
	}
	_post("talk_and_speak", body)


func speak_ai(text: String, voice_name: String = "") -> void:
	var body: Dictionary = {"cmd": "speak_ai", "text": text}
	if voice_name != "":
		body["voice_name"] = voice_name
	_post("speak_ai", body)


func listen_ai(audio_b64: String) -> void:
	_post("listen_ai", {"cmd": "listen_ai", "audio": audio_b64, "format": "wav"})


func listen_and_talk(audio_b64: String, personality: String, game_context: String, style: String = "dialogue", instructions: String = "", wants_voice: bool = false, voice_name: String = "") -> void:
	var body: Dictionary = {
		"cmd": "ai_dialog",
		"audio": audio_b64,
		"role": personality,
		"game_context": game_context,
		"style": style,
		"instructions": instructions if instructions != "" else "Respond as this character in 1-2 sentences.",
		"want_audio": wants_voice,
		"voice_name": voice_name
	}
	_post("talk_and_speak", body)


func game_state_parse(game_state: Dictionary, output_labels: Array = []) -> void:
	var body: Dictionary = {"cmd": "game_state_parse", "game_state": game_state}
	if output_labels.size() > 0:
		body["output_labels"] = output_labels
	_post("game_state_parse", body)


func game_state_summary(game_state: Dictionary) -> void:
	_post("game_state_summary", {"cmd": "game_state_summary", "game_state": game_state})


func train_ai(steps: int = 10, use_critic: bool = true, force_refresh: bool = false) -> void:
	_post("train_ai", {"cmd": "train_ai", "steps": steps, "use_critic": use_critic, "force_refresh": force_refresh})


func play_audio_from_base64(audio_b64: String, audio_player: AudioStreamPlayer3D) -> void:
	if audio_b64 == "":
		return
	var raw := Marshalls.base64_to_raw(audio_b64)
	var stream := AudioStreamWAV.new()
	stream.data = raw
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = 24000
	stream.stereo = false
	audio_player.stream = stream
	audio_player.play()
